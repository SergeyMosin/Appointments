<?php
namespace OCA\Appointments;

use Sabre\CalDAV\ICalendarObject;

class DavN implements ICalendarObject
{

    /**
     * @inheritDoc
     */
    function put($data)
    {
        // TODO: Implement put() method.
    }

    /**
     * @inheritDoc
     */
    function get()
    {
        return "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    }

    /**
     * @inheritDoc
     */
    function getContentType()
    {
        // TODO: Implement getContentType() method.
    }

    /**
     * @inheritDoc
     */
    function getETag()
    {
        // TODO: Implement getETag() method.
    }

    /**
     * @inheritDoc
     */
    function getSize()
    {
        // TODO: Implement getSize() method.
    }

    /**
     * @inheritDoc
     */
    function delete()
    {
        // TODO: Implement delete() method.
    }

    /**
     * @inheritDoc
     */
    function getName()
    {
        return "dav-handler";
    }

    /**
     * @inheritDoc
     */
    function setName($name)
    {
        // TODO: Implement setName() method.
    }

    /**
     * @inheritDoc
     */
    function getLastModified()
    {
        // TODO: Implement getLastModified() method.
    }
}