<?php
namespace OCA\Appointments;

use Sabre\DAV\Collection;
use Sabre\DAV\Exception\NotFound;
use Sabre\DAV\INode;
use Sabre\DAV\Node;

class DavC extends Collection
{

    /**
     * @inheritDoc
     */
    function getChildren()
    {
        return [new DavN()];
    }

    /**
     * @inheritDoc
     */
    function getName()
    {
        return "appointments";
    }

    function getChild($name)
    {

        if($name==="dav-handler") return new DavN();
        throw new NotFound('Node with name \'' . $name . '\' could not be found');
    }


}