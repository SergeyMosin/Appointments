<?php
namespace OCA\Appointments;
use \OCP\AppFramework\Middleware;

class Middle extends Middleware {

    /**
     * this replaces "bad words" with "********" in the output
     */
    public function beforeOutput($controller, $methodName, $output){

//        $controller->

        \OC::$server->getLogger()->error("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
        return $output;
    }

}
