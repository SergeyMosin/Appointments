<?php
namespace OCA\Appointments;

use OCP\Mail\IMailer;
use Sabre\CalDAV\ICalendarObject;
use Sabre\DAV\Exception\NotFound;
use Sabre\DAV\Server;
use Sabre\DAV\ServerPlugin;
use Sabre\HTTP\RequestInterface;
use Sabre\HTTP\ResponseInterface;
use Sabre\VObject\Component\VCalendar;
use Sabre\VObject\Component\VEvent;
use Sabre\VObject\Property;
use Sabre\VObject\Reader;

class DavP extends ServerPlugin
{

    const CT_CONFIRMED=0;
    const CT_CANCELED=1; // this counts for deleted events
    const CT_MODIFIED=2;

    /**
     * @var Server
     */
    protected $server;

    function initialize(Server $server)
    {
        $this->server = $server;
        $server->on('calendarObjectChange',
            [$this, 'calendarObjectChange']);
        $server->on('beforeUnbind',
            [$this, 'beforeUnbind']);
        $server->on('afterMethod:GET',
            [$this, 'httpAfterGet'],420);
    }

    function getName()
    {
        return 'DavP';
    }




    /**
     * This event is triggered after GET requests.
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @return void
     */
    function httpAfterGet(RequestInterface $request, ResponseInterface $response){


        \OC::$server->getLogger()->error("rrrrrrrrrrrrrrrrrrrrrrrrr");

        \OC::$server->getLogger()->error(var_export($response,true));


//        if (strpos($response->getHeader('Content-Type'), 'text/vcard') === false) {
//            return;
//        }
//
//        $target = $this->negotiateVCard($request->getHeader('Accept'), $mimeType);
//
//        $newBody = $this->convertVCard(
//            $response->getBody(),
//            $target
//        );
//
//        $response->setBody($newBody);
//        $response->setHeader('Content-Type', $mimeType . '; charset=utf-8');
//        $response->setHeader('Content-Length', strlen($newBody));

    }




    /**
     * FROM: Sabre\CalDAV\Schedule\Plugin.php
     *
     * This method is triggered whenever there was a calendar object gets
     * created or updated.
     *
     * @param RequestInterface $request HTTP request
     * @param ResponseInterface $response HTTP Response
     * @param VCalendar $vCal Parsed iCalendar object
     * @param mixed $calendarPath Path to calendar collection
     * @param mixed $modified The iCalendar object has been touched.
     * @param mixed $isNew Whether this was a new item or we're updating one
     * @return void
     */
    function calendarObjectChange(RequestInterface $request, ResponseInterface $response, VCalendar $vCal, $calendarPath, &$modified, $isNew)
    {

        // TODO: check $request for my cookies


        if ($isNew || !isset($vCal->VEVENT)) return;

        /* @var VEvent $evt */
        $evt = $vCal->VEVENT;

        if (!UtilsAppt::isAppointment($evt)
            || !isset($evt->STATUS)
            || $evt->STATUS->getValue() !== 'CONFIRMED') return;

        // TODO:Only continue if previous state had the


        $this->emailAttendees($evt, false);


//        if ($oldObj) {
//            // Destroy circular references so PHP will GC the object.
//            $oldObj->destroy();
//        }

    }


    /**
     * FROM: Sabre\CalDAV\Schedule\Plugin.php
     *
     * This method is triggered before a file gets deleted.
     *
     * We use this event to make sure that when this happens, attendees get
     * cancellations.
     *
     * @param string $path
     * @return void
     */
    function beforeUnbind($path)
    {

        // FIXME: We shouldn't trigger this functionality when we're issuing a MOVE. This is a hack (FROM: Sabre\CalDAV\Schedule\Plugin.php).
        if ($this->server->httpRequest->getMethod() === 'MOVE') return;


        try {
            $node = $this->server->tree->getNodeForPath($path);
        } catch (NotFound $e) {
            return;
        }

        if (!$node instanceof ICalendarObject) return;

        /* @var VCalendar */
        $co = Reader::read($node->get());

        if (!isset($co->VEVENT)) return;

        /* @var VEvent $evt */
        $evt = $co->VEVENT;

        if (!UtilsAppt::isAppointment($evt)
            || !isset($evt->STATUS)
            || $evt->STATUS->getValue() !== 'CONFIRMED') return;

        $this->emailAttendees($evt, true);
    }


    /**
     * Send emails to attendees and log errors if any occurred
     * @param VEvent $evt
     * @param bool $event_deleted
     * @return bool
     */
    function emailAttendees($evt, $event_deleted)
    {

        $mailer=\OC::$server->getMailer();

        if (!isset($evt->ATTENDEE)) return false;


        // Let's make sure that SCHEDULE-AGENT === CLIENT
        // TODO: is X-something param needed to be 100% sure ???
        foreach ($evt->ATTENDEE as $a) {
            if (isset($a['SCHEDULE-AGENT'])
                && $a['SCHEDULE-AGENT']->getValue() === 'CLIENT') {
                // Send email to $a



                \OC::$server->getLogger()->error("cdscdddsdcsdcsdcdscdscdscdscdscdscdscdscdscdsdcdscdscscsdcdsccscdsdscdscdscdscdscdscdscdscdsdsdsc");


//                $tml = $this->mailer->createEMailTemplate('appointments.app.email');
//                $tml->setSubject($subject);
//                $tml->addBodyText($body);
//                $tml->addBodyText($this->l->t("Thank you"));
//
//                $tml->addFooter("Booked via Nextcloud Appointments App");
//
//                $msg = $this->mailer->createMessage();
//                $msg->setFrom(array($org_email));
//                $msg->setTo(array($da[0]));
//                $msg->useTemplate($tml);
//                if($ics_attachment!==null){
//                    $msg->attach($ics_attachment);
//                }
//
//                try {
//                    $this->mailer->send($msg);
//                } catch (\Exception $e) {
//                    \OC::$server->getLogger()->error("Can not send email to " . $da[0]);
//                }
            }
        }

        return true;
    }
}
