<?php

namespace OCA\Appointments\AppInfo;

use OCA\Appointments\DavAuth;
use OCP\AppFramework\App;
use OCP\EventDispatcher\IEventDispatcher;
use OCP\SabrePluginEvent;
use Sabre\DAV\Auth\Plugin;
use Symfony\Component\EventDispatcher\GenericEvent;


class Application extends App {

    /**
     * Application constructor.
     */
    public function __construct(){

        parent::__construct('appointments');

//        $container = $this->getContainer();
//
//        /* @var IEventDispatcher $eventDispatcher */
//        $dispatcher = $container->query(IEventDispatcher::class);
//        $dispatcher->addListener('OCA\DAV\Connector\Sabre::authInit', function(SabrePluginEvent $event) {
//            /* @var Plugin */
//            $ap=$event->getServer()->getPlugin('auth');
//            if($ap!==null){
//                $ap->addBackend(new DavAuth());
//            }
//        });

//        $dispatcher->addListener('\OCA\DAV\CalDAV\CalDavBackend::updateCalendarObject', function(GenericEvent $event) {
//            /* @var Plugin */
//            $ap=$event->getServer()->getPlugin('auth');
//            if($ap!==null){
//                $ap->addBackend(new DavAuth());
//            }
//        });


        //


    }
}