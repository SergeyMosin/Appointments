<?php

namespace OCA\Appointments\AppInfo;

use OCA\Appointments\DavAuth;
use OCP\AppFramework\App;
use OCP\EventDispatcher\IEventDispatcher;
use OCP\SabrePluginEvent;
use Sabre\DAV\Auth\Plugin;
use Symfony\Component\EventDispatcher\GenericEvent;
use OCA\DAV\Connector\Sabre;

class Application extends App {

    /**
     * Application constructor.
     */
    public function __construct(){

        parent::__construct('appointments');

                \OC::$server->getLogger()->error("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");

        /** @param SabrePluginEvent $event */
        $authInitListener=function($event){
            /* @var Plugin */
            $ap=$event->getServer()->getPlugin('auth');
            if($ap!==null){
//                \OC::$server->getLogger()->error("aaaaaaaaaa");
                $ap->addBackend(new DavAuth('principals/users/'));
            }
        };

        $container = $this->getContainer();
        $dispatcher = $container->query(IEventDispatcher::class);
        $dispatcher->addListener('OCA\DAV\Connector\Sabre::authInit',$authInitListener);

        if(method_exists(\OC::$server,'getEventDispatcher')) {
            $dispatcher_old = \OC::$server->getEventDispatcher();
            $dispatcher_old->addListener('OCA\DAV\Connector\Sabre::authInit',$authInitListener);
        }
    }
}