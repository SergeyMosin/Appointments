<?php

namespace OCA\Appointments;


use Sabre\DAV\Auth\Backend\BackendInterface;
use Sabre\HTTP\RequestInterface;
use Sabre\HTTP\ResponseInterface;
use Sabre\DAV\Auth\Backend\AbstractBasic;

class DavAuth implements BackendInterface
{
    /** @var string */
    private $principalPrefix;

    public function __construct($principalPrefix){
        $this->principalPrefix=$principalPrefix;
    }

    /**
     * @inheritDoc
     */
    function check(RequestInterface $request, ResponseInterface $response){
        $url = $request->getPath();
        if(strpos($url,"Serioga/cal-mmmm")!==false){
            return [true, $this->principalPrefix."Serioga"];
        }else{
            return [false, "No public access to this resource."];
        }
    }

    /**
     * @inheritDoc
     */
    function challenge(RequestInterface $request, ResponseInterface $response){
        // empty
    }

}