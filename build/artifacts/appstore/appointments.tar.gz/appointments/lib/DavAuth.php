<?php

namespace OCA\Appointments;


use Sabre\DAV\Auth\Backend\BackendInterface;
use Sabre\HTTP\RequestInterface;
use Sabre\HTTP\ResponseInterface;

class DavAuth implements BackendInterface {

    /**
     * @inheritDoc
     */
    function check(RequestInterface $request, ResponseInterface $response){
        $url = $request->getPath();
        if(strpos($url,"appointments")===0){
            return [true, "principals/system/public"];
        }else{
            return [false, "No public access to this resource."];
        }
    }

    /**
     * @inheritDoc
     */
    function challenge(RequestInterface $request, ResponseInterface $response){
        // empty
    }
}