OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Potvrdiť",
    "Cancel" : "Zrušiť",
    "Info" : "Info",
    "Email" : "E-mail",
    "Close" : "Zavrieť",
    "Copy public link" : "Kopírovať verejný odkaz",
    "Address" : "Adresa",
    "Apply" : "Aplikovať",
    "Start" : "Začať",
    "close" : "Zatvoriť"
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
