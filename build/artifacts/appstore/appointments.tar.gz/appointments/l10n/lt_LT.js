OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Patvirtinti",
    "Cancel" : "Atsisakyti",
    "Info" : "Informacija",
    "Email" : "El. paštas",
    "Close" : "Užverti",
    "Copy public link" : "Kopijuoti viešąją nuorodą",
    "Address" : "Adresas",
    "Apply" : "Taikyti",
    "Start" : "Pradžia",
    "close" : "užverti",
    "Name:" : "Vardas:"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
