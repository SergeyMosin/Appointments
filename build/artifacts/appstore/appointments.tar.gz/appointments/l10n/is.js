OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Staðfesta",
    "Cancel" : "Hætta við",
    "Info" : "Upplýsingar",
    "Email" : "Tölvupóstur",
    "Close" : "Loka",
    "Copy public link" : "Afrita opinberan tengil",
    "Address" : "Heimilisfang",
    "Apply" : "Virkja",
    "Start" : "Start",
    "close" : "loka"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
