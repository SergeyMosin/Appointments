OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bevestig",
    "Cancel" : "Kanselleer",
    "Info" : "Inligting",
    "Close" : "Sluit",
    "Deleted" : "Geskrap",
    "Confirmed" : "Bevestig",
    "Start" : "Start",
    "Location:" : "Ligging:"
},
"nplurals=2; plural=(n != 1);");
