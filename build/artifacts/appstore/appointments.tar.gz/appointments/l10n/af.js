OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bevestig",
    "Cancel" : "Kanselleer",
    "Info" : "Inligting",
    "Close" : "Sluit",
    "Remove" : "Verwyder",
    "Warning" : "Waarskuwing",
    "Start" : "Start",
    "Deleted" : "Geskrap",
    "Confirmed" : "Bevestig",
    "Error" : "Fout",
    "Location:" : "Ligging:",
    "Back" : "Terug",
    "Next" : "Volgende",
    "An error has occurred" : "’n Fout het voorgekom"
},
"nplurals=2; plural=(n != 1);");
