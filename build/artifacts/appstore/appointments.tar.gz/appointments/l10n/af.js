OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bevestig",
    "Cancel" : "Kanselleer",
    "Info" : "Inligting",
    "Email" : "E-pos",
    "Close" : "Sluit",
    "Address" : "Adres",
    "Start" : "Start"
},
"nplurals=2; plural=(n != 1);");
