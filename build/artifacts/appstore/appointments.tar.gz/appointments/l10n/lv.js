OC.L10N.register(
    "appointments",
    {
    "Available" : "Pieejams",
    "Confirm" : "Apstiprināt",
    "Cancel" : "Atcelt",
    "Info" : "Info",
    "Close" : "Aizvērt",
    "Remove" : "Noņemt",
    "Warning" : "Brīdinājums",
    "Start" : "Sākt",
    "Apply" : "Apstiprināt",
    "Deleted" : "Dzēstie",
    "Confirmed" : "Apstiprināts",
    "Error" : "Kļūda",
    "Location:" : "Vieta:",
    "Back" : "Atpakaļ",
    "Next" : "Nākamā",
    "An error has occurred" : "Radusies kļūda"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
