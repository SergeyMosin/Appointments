OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Apstiprināt",
    "Cancel" : "Atcelt",
    "Info" : "Info",
    "Available" : "Pieejams",
    "Close" : "Aizvērt",
    "Apply" : "Apstiprināt",
    "Deleted" : "Dzēstie",
    "Confirmed" : "Apstiprināts",
    "Start" : "Sākt",
    "Location:" : "Vieta:",
    "Back" : "Atpakaļ",
    "Next" : "Nākamā",
    "An error has occurred" : "Radusies kļūda"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
