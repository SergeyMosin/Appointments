OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Apstiprināt",
    "Cancel" : "Atcelt",
    "Info" : "Info",
    "Close" : "Aizvērt",
    "Apply" : "Apstiprināt",
    "Start" : "Sākt"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
