OC.L10N.register(
    "appointments",
    {
    "Confirm" : "تائید",
    "Cancel" : "لغو",
    "Info" : "اطلاعات",
    "Close" : "بستن",
    "Copy public link" : "پیوند عمومی را کپی کنید",
    "Apply" : "اعمال",
    "Start" : "شروع کنید",
    "close" : "بستن"
},
"nplurals=2; plural=(n > 1);");
