OC.L10N.register(
    "appointments",
    {
    "Confirm" : "تائید",
    "Cancel" : "لغو",
    "Info" : "اطلاعات",
    "Available" : "در دسترس",
    "Close" : "بستن",
    "Remove" : "حذف",
    "Copy public link" : "پیوند عمومی را کپی کنید",
    "Start" : "شروع کنید",
    "Apply" : "اعمال",
    "Deleted" : "حذف شده",
    "Confirmed" : "تایید شده",
    "close" : "بستن",
    "Location:" : "مکان:",
    "Back" : "بازگشت",
    "Next" : "بعدی"
},
"nplurals=2; plural=(n > 1);");
