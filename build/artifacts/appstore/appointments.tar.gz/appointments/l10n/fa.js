OC.L10N.register(
    "appointments",
    {
    "Available" : "در دسترس",
    "Confirm" : "تائید",
    "Cancel" : "لغو",
    "Info" : "اطلاعات",
    "Close" : "بستن",
    "Remove" : "حذف",
    "Warning" : "هشدار",
    "Start" : "شروع کنید",
    "Apply" : "اعمال",
    "Deleted" : "حذف شده",
    "Confirmed" : "تایید شده",
    "close" : "بستن",
    "Simple" : "ساده",
    "Error" : "خطا",
    "Location:" : "مکان:",
    "Back" : "بازگشت",
    "Next" : "بعدی"
},
"nplurals=2; plural=(n > 1);");
