OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Encaboxar",
    "Info" : "Info",
    "Close" : "Zarrar",
    "Remove" : "Desaniciar",
    "Start" : "Aniciu",
    "Apply" : "Aplicar",
    "Deleted" : "Desanicióse",
    "Confirmed" : "Confirmáu",
    "Location:" : "Llocalización:",
    "Back" : "Atrás",
    "Next" : "Siguiente",
    "An error has occurred" : "Asocedió un fallu"
},
"nplurals=2; plural=(n != 1);");
