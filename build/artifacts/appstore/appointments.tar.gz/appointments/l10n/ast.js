OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Encaboxar",
    "Info" : "Info",
    "Email" : "email",
    "Close" : "Zarrar",
    "Address" : "Direición",
    "Apply" : "Aplicar",
    "Start" : "Aniciu"
},
"nplurals=2; plural=(n != 1);");
