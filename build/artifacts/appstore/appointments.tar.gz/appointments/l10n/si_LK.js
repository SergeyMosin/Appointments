OC.L10N.register(
    "appointments",
    {
    "Cancel" : "අවලංගු කරන්න",
    "Password" : "මුර පදය",
    "Info" : "Info",
    "Delete" : "ඉවත් කරන්න",
    "Settings" : "සැකසුම්",
    "Close" : "වසන්න",
    "Remove" : "ඉවත් කරන්න ",
    "Loading" : "Loading",
    "Warning" : "අවවාදය",
    "Error" : "දෝෂයක්",
    "Edit" : "සකසන්න",
    "Title" : "මාතෘකාව",
    "URL" : "URL",
    "Save" : "සුරකින්න",
    "Next" : "ඊලඟ"
},
"nplurals=2; plural=(n != 1);");
