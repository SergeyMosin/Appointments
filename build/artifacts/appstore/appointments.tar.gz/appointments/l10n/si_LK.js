OC.L10N.register(
    "appointments",
    {
    "Cancel" : "අවලංගු කරන්න",
    "Info" : "Info",
    "Email" : "විද්‍යුත් තැපෑල",
    "Close" : "වසන්න",
    "Address" : "ලිපිනය"
},
"nplurals=2; plural=(n != 1);");
