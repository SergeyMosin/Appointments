OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Otkaži",
    "Info" : "Info",
    "Close" : "Zatvori",
    "Remove" : "Ukloni",
    "Deleted" : "Obrisano",
    "close" : "zatvori",
    "15 Minutes" : "15 minuta",
    "30 Minutes" : "30 minuta",
    "1 Hour" : "1 sat",
    "2 Hours" : "2 sata",
    "Error" : "Error",
    "Warning" : "Upozorenje",
    "Location:" : "Lokacija:",
    "Back" : "Nazad"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
