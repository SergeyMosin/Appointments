OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmasi",
    "Cancel" : "Membatalkan",
    "Info" : "Info",
    "Close" : "Tutup",
    "Remove" : "Buang",
    "Copy public link" : "Salin tautan publik",
    "Start" : "Mulai",
    "Apply" : "Terapkan",
    "Deleted" : "Dihapus",
    "Location:" : "Lokasi:",
    "Back" : "Kembali",
    "Next" : "Berikutnya",
    "An error has occurred" : "Sebuah kesalahan yang terjadi"
},
"nplurals=1; plural=0;");
