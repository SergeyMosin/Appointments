OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmasi",
    "Cancel" : "Membatalkan",
    "Info" : "Info",
    "Close" : "Tutup",
    "Apply" : "Terapkan",
    "Deleted" : "Dihapus",
    "Start" : "Mulai",
    "Location:" : "Lokasi:",
    "Back" : "Kembali",
    "Next" : "Berikutnya",
    "An error has occurred" : "Sebuah kesalahan yang terjadi"
},
"nplurals=1; plural=0;");
