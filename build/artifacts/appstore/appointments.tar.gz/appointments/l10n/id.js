OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmasi",
    "Cancel" : "Membatalkan",
    "Info" : "Info",
    "Close" : "Tutup",
    "Apply" : "Terapkan",
    "Start" : "Mulai"
},
"nplurals=1; plural=0;");
