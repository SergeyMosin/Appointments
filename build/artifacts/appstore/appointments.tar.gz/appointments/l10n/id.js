OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmasi",
    "Cancel" : "Membatalkan",
    "Info" : "Info",
    "Email" : "Surel",
    "Close" : "Tutup",
    "Address" : "Alamat",
    "Apply" : "Terapkan",
    "Start" : "Mulai"
},
"nplurals=1; plural=0;");
