OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirm",
    "Cancel" : "Cancel",
    "Info" : "Info",
    "Close" : "Close",
    "Apply" : "Apply",
    "Deleted" : "Deleted",
    "Confirmed" : "Confirmed",
    "Start" : "Start",
    "Location:" : "Location:"
},
"nplurals=2; plural=(n != 1);");
