OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirm",
    "Cancel" : "Cancel",
    "Info" : "Info",
    "Close" : "Close",
    "Remove" : "Remove",
    "Warning" : "Warning",
    "Start" : "Start",
    "Apply" : "Apply",
    "Deleted" : "Deleted",
    "Confirmed" : "Confirmed",
    "Simple" : "Simple",
    "Error" : "Error",
    "Location:" : "Location:",
    "Back" : "Back",
    "Next" : "Next",
    "An error has occurred" : "An error has occurred"
},
"nplurals=2; plural=(n != 1);");
