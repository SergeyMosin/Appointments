OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirm",
    "Cancel" : "Cancel",
    "Info" : "Info",
    "Close" : "Close",
    "Apply" : "Apply",
    "Start" : "Start"
},
"nplurals=2; plural=(n != 1);");
