OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmi",
    "Cancel" : "Nuligi",
    "Info" : "Info",
    "Available" : "Disponeblaj",
    "Close" : "Malfermi",
    "Apply" : "Validigi",
    "Deleted" : "Forigita",
    "Confirmed" : "Konfirmita",
    "Canceled" : "Nuligita",
    "Start" : "Komenco",
    "Location:" : "Loko:"
},
"nplurals=2; plural=(n != 1);");
