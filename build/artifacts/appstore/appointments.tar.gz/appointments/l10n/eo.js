OC.L10N.register(
    "appointments",
    {
    "Available" : "Disponeblaj",
    "Confirm" : "Konfirmi",
    "Cancel" : "Nuligi",
    "Info" : "Info",
    "Close" : "Malfermi",
    "Remove" : "Forigi",
    "Warning" : "Averto",
    "Start" : "Komenco",
    "Apply" : "Validigi",
    "Deleted" : "Forigita",
    "Confirmed" : "Konfirmita",
    "Canceled" : "Nuligita",
    "Advanced Settings" : "Detalaj agordoj",
    "Error" : "Eraro",
    "Location:" : "Loko:",
    "Back" : "Antaŭen",
    "Next" : "Sekva"
},
"nplurals=2; plural=(n != 1);");
