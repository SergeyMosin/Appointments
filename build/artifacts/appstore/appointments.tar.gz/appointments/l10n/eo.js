OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmi",
    "Cancel" : "Nuligi",
    "Info" : "Info",
    "Close" : "Malfermi",
    "Apply" : "Validigi",
    "Start" : "Komenco"
},
"nplurals=2; plural=(n != 1);");
