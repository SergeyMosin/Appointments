OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmi",
    "Cancel" : "Nuligi",
    "Info" : "Info",
    "Available" : "Disponeblaj",
    "Close" : "Malfermi",
    "Remove" : "Forigi",
    "Start" : "Komenco",
    "Apply" : "Validigi",
    "Deleted" : "Forigita",
    "Confirmed" : "Konfirmita",
    "Canceled" : "Nuligita",
    "Location:" : "Loko:",
    "Back" : "Antaŭen",
    "Next" : "Sekva"
},
"nplurals=2; plural=(n != 1);");
