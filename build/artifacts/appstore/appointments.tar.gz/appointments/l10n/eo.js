OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmi",
    "Cancel" : "Nuligi",
    "Info" : "Info",
    "Email" : "Retpoŝtadreso",
    "Close" : "Malfermi",
    "Address" : "Adreso",
    "Apply" : "Validigi",
    "Start" : "Komenco"
},
"nplurals=2; plural=(n != 1);");
