OC.L10N.register(
    "appointments",
    {
    "Cancel" : "இரத்து செய்க",
    "Info" : "Info",
    "Email" : "மின்னஞ்சல்",
    "Close" : "மூடுக",
    "Address" : "முகவரி"
},
"nplurals=2; plural=(n != 1);");
