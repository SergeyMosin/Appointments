OC.L10N.register(
    "appointments",
    {
    "Cancel" : "இரத்து செய்க",
    "Info" : "Info",
    "Close" : "மூடுக",
    "Remove" : "அகற்றுக",
    "Warning" : "எச்சரிக்கை",
    "Error" : "வழு",
    "Location:" : "இடம்:",
    "Back" : "பின்னுக்கு",
    "Next" : "அடுத்த"
},
"nplurals=2; plural=(n != 1);");
