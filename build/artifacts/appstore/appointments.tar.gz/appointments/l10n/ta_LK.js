OC.L10N.register(
    "appointments",
    {
    "Cancel" : "இரத்து செய்க",
    "Info" : "Info",
    "Delete" : "நீக்குக",
    "Settings" : "அமைப்புகள்",
    "Close" : "மூடுக",
    "Remove" : "அகற்றுக",
    "Loading" : "Loading",
    "Warning" : "எச்சரிக்கை",
    "Error" : "வழு",
    "Edit" : "தொகுக்க",
    "Title" : "தலைப்பு",
    "URL" : "URL",
    "Save" : "சேமிக்க ",
    "Location:" : "இடம்:",
    "Back" : "பின்னுக்கு",
    "Next" : "அடுத்த"
},
"nplurals=2; plural=(n != 1);");
