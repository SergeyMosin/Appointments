OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потврди",
    "Cancel" : "Одустани",
    "Info" : "Инфо",
    "Available" : "Доступно",
    "Close" : "Затвори",
    "Remove" : "Уклони",
    "Start" : "Почетак",
    "Apply" : "Примени",
    "Deleted" : "Обрисано",
    "Confirmed" : "Потврђен",
    "Canceled" : "Отказано",
    "close" : "затвори",
    "Name:" : "Име:",
    "Location:" : "Локација:",
    "Back" : "Назад",
    "Next" : "Следећа",
    "An error has occurred" : "Дошло је до грешке"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
