OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Diddymu",
    "Password" : "Cyfrinair",
    "Info" : "Info",
    "Delete" : "Dileu",
    "Settings" : "Gosodiadau",
    "Close" : "Cau",
    "Remove" : "Gwaredu",
    "Save" : "Cadw",
    "Loading" : "Llwytho",
    "Warning" : "Rhybudd",
    "Error" : "Gwall",
    "Edit" : "Golygu",
    "Title" : "Teitl",
    "URL" : "URL",
    "Deleted" : "Wedi dileu",
    "Confirmed" : "Cadarnhawyd",
    "Location:" : "Lleoliad:",
    "Back" : "Nôl",
    "Next" : "Nesaf"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
