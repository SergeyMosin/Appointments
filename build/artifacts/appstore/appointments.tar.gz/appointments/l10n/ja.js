OC.L10N.register(
    "appointments",
    {
    "Confirm" : "確認",
    "Cancel" : "キャンセル",
    "Info" : "情報",
    "Email" : "メール",
    "Close" : "閉じる",
    "Copy public link" : "公開リンクをコピー",
    "Address" : "住所",
    "Apply" : "適用",
    "Start" : "出発地点",
    "close" : "閉じる"
},
"nplurals=1; plural=0;");
