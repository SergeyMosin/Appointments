OC.L10N.register(
    "appointments",
    {
    "Confirm" : "確認",
    "Cancel" : "キャンセル",
    "Info" : "情報",
    "Close" : "閉じる",
    "Copy public link" : "公開リンクをコピー",
    "Apply" : "適用",
    "Start" : "出発地点",
    "close" : "閉じる"
},
"nplurals=1; plural=0;");
