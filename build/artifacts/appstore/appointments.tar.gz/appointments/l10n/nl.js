OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bevestigen",
    "Cancel" : "Annuleren",
    "Info" : "Info",
    "Email" : "Email",
    "Close" : "Sluiten",
    "Copy public link" : "Kopieer openbare link",
    "Address" : "Adres",
    "Apply" : "Toepassen",
    "Start" : "Start",
    "close" : "sluiten",
    "Name:" : "Naam:"
},
"nplurals=2; plural=(n != 1);");
