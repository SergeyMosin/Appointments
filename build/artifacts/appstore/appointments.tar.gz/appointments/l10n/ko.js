OC.L10N.register(
    "appointments",
    {
    "Confirm" : "확인",
    "Cancel" : "취소",
    "Info" : "정보",
    "Email" : "이메일",
    "Close" : "닫기",
    "Copy public link" : "공개 링크 복사",
    "Address" : "주소",
    "Apply" : "적용",
    "Start" : "Start",
    "close" : "닫기"
},
"nplurals=1; plural=0;");
