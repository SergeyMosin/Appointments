OC.L10N.register(
    "appointments",
    {
    "Confirm" : "확인",
    "Cancel" : "취소",
    "Info" : "정보",
    "Available" : "사용 가능",
    "Close" : "닫기",
    "Copy public link" : "공개 링크 복사",
    "Apply" : "적용",
    "Deleted" : "삭제함",
    "Confirmed" : "확인됨",
    "Start" : "Start",
    "close" : "닫기",
    "Location:" : "위치:",
    "Back" : "뒤로",
    "Next" : "Next"
},
"nplurals=1; plural=0;");
