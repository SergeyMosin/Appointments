OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Ofbriechen",
    "Info" : "Info",
    "Email" : "Email",
    "Close" : "Zoumaachen",
    "Address" : "Adress",
    "Apply" : "Uwenden"
},
"nplurals=2; plural=(n != 1);");
