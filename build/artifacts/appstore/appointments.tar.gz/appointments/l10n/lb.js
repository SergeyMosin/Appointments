OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Ofbriechen",
    "Info" : "Info",
    "Close" : "Zoumaachen",
    "Remove" : "Läschen",
    "Warning" : "Warnung",
    "Apply" : "Uwenden",
    "Deleted" : "Geläscht",
    "Error" : "Fehler",
    "Location:" : "Uert:",
    "Back" : "Zeréck",
    "Next" : "Weider"
},
"nplurals=2; plural=(n != 1);");
