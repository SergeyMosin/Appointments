OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Ofbriechen",
    "Password" : "Passwuert",
    "Info" : "Info",
    "Delete" : "Läschen",
    "Settings" : "Astellungen",
    "Close" : "Zoumaachen",
    "Remove" : "Läschen",
    "Save" : "Späicheren",
    "Loading" : "Loading",
    "Apply" : "Uwenden",
    "Edit" : "Änneren",
    "Title" : "Titel",
    "URL" : "URL",
    "Error" : "Fehler",
    "Deleted" : "Geläscht",
    "Warning" : "Warnung",
    "Location:" : "Uert:",
    "Back" : "Zeréck",
    "Next" : "Weider"
},
"nplurals=2; plural=(n != 1);");
