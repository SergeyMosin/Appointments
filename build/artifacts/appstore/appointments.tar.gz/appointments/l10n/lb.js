OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Ofbriechen",
    "Info" : "Info",
    "Close" : "Zoumaachen",
    "Remove" : "Läschen",
    "Apply" : "Uwenden",
    "Deleted" : "Geläscht",
    "Location:" : "Uert:",
    "Back" : "Zeréck",
    "Next" : "Weider"
},
"nplurals=2; plural=(n != 1);");
