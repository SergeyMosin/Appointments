OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Ofbriechen",
    "Info" : "Info",
    "Close" : "Zoumaachen",
    "Apply" : "Uwenden",
    "Deleted" : "Geläscht",
    "Location:" : "Uert:"
},
"nplurals=2; plural=(n != 1);");
