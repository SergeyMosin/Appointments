OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Ofbriechen",
    "Password" : "Passwuert",
    "Info" : "Info",
    "Delete" : "Läschen",
    "Settings" : "Astellungen",
    "Close" : "Zoumaachen",
    "Remove" : "Läschen",
    "Loading" : "Loading",
    "Apply" : "Uwenden",
    "Warning" : "Warnung",
    "Error" : "Fehler",
    "Edit" : "Änneren",
    "Title" : "Titel",
    "URL" : "URL",
    "Save" : "Späicheren",
    "Deleted" : "Geläscht",
    "Location:" : "Uert:",
    "Back" : "Zeréck",
    "Next" : "Weider"
},
"nplurals=2; plural=(n != 1);");
