OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Dayandır",
    "Info" : "Info",
    "Close" : "Bağla",
    "Remove" : "Sil",
    "Warning" : "Xəbərdarlıq",
    "Deleted" : "Silinib",
    "15 Minutes" : "15 Dəqiqqə",
    "30 Minutes" : "30 Dəqiqqə",
    "1 Hour" : "1 Saat",
    "2 Hours" : "2 Saat",
    "Error" : "Səhv",
    "Location:" : "Ərazi:",
    "Next" : "Növbəti"
},
"nplurals=2; plural=(n != 1);");
