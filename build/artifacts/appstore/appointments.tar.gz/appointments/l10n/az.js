OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Dayandır",
    "Info" : "Info",
    "Close" : "Bağla",
    "Remove" : "Sil",
    "Warning" : "Xəbərdarlıq",
    "Deleted" : "Silinib",
    "Error" : "Səhv",
    "Location:" : "Ərazi:",
    "Next" : "Növbəti"
},
"nplurals=2; plural=(n != 1);");
