OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Dayandır",
    "Password" : "Şifrə",
    "Info" : "Info",
    "Delete" : "Sil",
    "Settings" : "Quraşdırmalar",
    "Close" : "Bağla",
    "Remove" : "Sil",
    "Save" : "Saxla",
    "Loading" : "Loading",
    "1 Hour" : "1 Saat",
    "2 Hours" : "2 Saat",
    "Edit" : "Dəyişiklik et",
    "Title" : "Başlıq",
    "URL" : "URL",
    "Error" : "Səhv",
    "Deleted" : "Silinib",
    "Warning" : "Xəbərdarlıq",
    "Location:" : "Ərazi:",
    "Next" : "Növbəti"
},
"nplurals=2; plural=(n != 1);");
