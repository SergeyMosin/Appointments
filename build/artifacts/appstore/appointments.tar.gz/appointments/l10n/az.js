OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Dayandır",
    "Info" : "Info",
    "Email" : "Email",
    "Close" : "Bağla",
    "Address" : "Ünvan"
},
"nplurals=2; plural=(n != 1);");
