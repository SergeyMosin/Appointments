OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ۋاز كەچ",
    "Password" : "ئىم",
    "Info" : "Info",
    "Delete" : "ئۆچۈر",
    "Settings" : "تەڭشەكلەر",
    "Close" : "ياپ",
    "Remove" : "چىقىرىۋەت",
    "Save" : "ساقلا",
    "Loading" : "Loading",
    "Edit" : "تەھرىر",
    "Title" : "ماۋزۇ",
    "URL" : "URL",
    "Error" : "خاتالىق",
    "Deleted" : "ئۆچۈرۈلدى",
    "Warning" : "ئاگاھلاندۇرۇش",
    "Next" : "كېيىنكى"
},
"nplurals=2; plural=(n != 1);");
