OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ۋاز كەچ",
    "Info" : "Info",
    "Delete" : "ئۆچۈر",
    "Settings" : "تەڭشەكلەر",
    "Close" : "ياپ",
    "Remove" : "چىقىرىۋەت",
    "Loading" : "Loading",
    "Warning" : "ئاگاھلاندۇرۇش",
    "Error" : "خاتالىق",
    "Edit" : "تەھرىر",
    "Title" : "ماۋزۇ",
    "URL" : "URL",
    "Save" : "ساقلا",
    "Deleted" : "ئۆچۈرۈلدى",
    "Next" : "كېيىنكى"
},
"nplurals=2; plural=(n != 1);");
