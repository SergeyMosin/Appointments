OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ۋاز كەچ",
    "Info" : "Info",
    "Email" : "تورخەت",
    "Close" : "ياپ",
    "Address" : "ئادرېس"
},
"nplurals=1; plural=0;");
