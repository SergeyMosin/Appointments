OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ۋاز كەچ",
    "Password" : "ئىم",
    "Info" : "Info",
    "Settings" : "تەڭشەكلەر",
    "Title" : "ماۋزۇ",
    "URL" : "URL",
    "Save" : "ساقلا",
    "Remove" : "چىقىرىۋەت",
    "Add" : "قوش",
    "OK" : "جەزملە",
    "Delete" : "ئۆچۈر",
    "Location" : "ئورنى",
    "Phone" : "تېلېفون",
    "Deleted" : "ئۆچۈرۈلدى",
    "Warning" : "ئاگاھلاندۇرۇش",
    "Advanced" : "ئالىي",
    "Edit" : "تەھرىر",
    "Next" : "كېيىنكى",
    "Email" : "تورخەت"
},
"nplurals=2; plural=(n != 1);");
