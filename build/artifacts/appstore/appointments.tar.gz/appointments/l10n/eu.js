OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Berretsi",
    "Cancel" : "Utzi",
    "We have sent an email to %s, please open it and click on the confirmation link to finalize your appointment request" : "Emaila bidali dugu %s helbidera, mesedez ireki eta klikatu baieztapen esteka zure hitzordu eskaera amaitzeko",
    "Info" : "Informazioa",
    "Email" : "Helbide elektronikoa",
    "Close" : "Itxi",
    "Copy public link" : "Kopiatu esteka publikoa",
    "Address" : "Helbidea",
    "Apply" : "Aplikatu",
    "Start" : "Hasi",
    "close" : "itxi"
},
"nplurals=2; plural=(n != 1);");
