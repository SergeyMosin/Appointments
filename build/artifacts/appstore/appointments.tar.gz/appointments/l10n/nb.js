OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekreft",
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Remove" : "Fjern",
    "Warning" : "Advarsel",
    "Start" : "Start",
    "Apply" : "Bruk",
    "Deleted" : "Slettet",
    "Confirmed" : "Bekreftet",
    "close" : "lukk",
    "Advanced Settings" : "Avanserte innstillinger",
    "Simple" : "Enkel",
    "Error" : "Feil",
    "Location:" : "Sted:",
    "Back" : "Tilbake",
    "Next" : "Neste",
    "An error has occurred" : "En feil oppstod"
},
"nplurals=2; plural=(n != 1);");
