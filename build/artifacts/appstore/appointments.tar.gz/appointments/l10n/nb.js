OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekreft",
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Email" : "E-post",
    "Close" : "Lukk",
    "Copy public link" : "Kopier offentlig lenke",
    "Address" : "Adresse",
    "Apply" : "Bruk",
    "Start" : "Start"
},
"nplurals=2; plural=(n != 1);");
