OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekreft",
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Copy public link" : "Kopier offentlig lenke",
    "Apply" : "Bruk",
    "Deleted" : "Slettet",
    "Confirmed" : "Bekreftet",
    "Start" : "Start",
    "Location:" : "Sted:",
    "Back" : "Tilbake",
    "Next" : "Neste"
},
"nplurals=2; plural=(n != 1);");
