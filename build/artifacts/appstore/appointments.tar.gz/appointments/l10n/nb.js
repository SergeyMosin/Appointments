OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekreft",
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Remove" : "Fjern",
    "Copy public link" : "Kopier offentlig lenke",
    "Start" : "Start",
    "Apply" : "Bruk",
    "Deleted" : "Slettet",
    "Confirmed" : "Bekreftet",
    "close" : "lukk",
    "Location:" : "Sted:",
    "Back" : "Tilbake",
    "Next" : "Neste",
    "An error has occurred" : "En feil oppstod"
},
"nplurals=2; plural=(n != 1);");
