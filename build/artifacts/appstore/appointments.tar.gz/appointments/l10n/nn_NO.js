OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Apply" : "Anvend",
    "Deleted" : "Sletta",
    "Confirmed" : "Stadfesta",
    "Start" : "Start",
    "Back" : "Tilbake",
    "Next" : "Neste"
},
"nplurals=2; plural=(n != 1);");
