OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Remove" : "Fjern",
    "Start" : "Start",
    "Apply" : "Anvend",
    "Warning" : "Åtvaring",
    "Error" : "Feil",
    "Deleted" : "Sletta",
    "Confirmed" : "Stadfesta",
    "Back" : "Tilbake",
    "Next" : "Neste",
    "An error has occurred" : "Ein feil har oppstått"
},
"nplurals=2; plural=(n != 1);");
