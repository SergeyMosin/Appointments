OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Apply" : "Anvend",
    "Deleted" : "Sletta",
    "Confirmed" : "Stadfesta",
    "Start" : "Start"
},
"nplurals=2; plural=(n != 1);");
