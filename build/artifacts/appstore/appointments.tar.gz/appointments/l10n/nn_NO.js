OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Email" : "E-post",
    "Close" : "Lukk",
    "Address" : "Adresse",
    "Apply" : "Anvend",
    "Start" : "Start"
},
"nplurals=2; plural=(n != 1);");
