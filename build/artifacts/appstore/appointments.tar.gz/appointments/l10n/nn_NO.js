OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Remove" : "Fjern",
    "Warning" : "Åtvaring",
    "Start" : "Start",
    "Apply" : "Anvend",
    "Deleted" : "Sletta",
    "Confirmed" : "Stadfesta",
    "Error" : "Feil",
    "Back" : "Tilbake",
    "Next" : "Neste",
    "An error has occurred" : "Ein feil har oppstått"
},
"nplurals=2; plural=(n != 1);");
