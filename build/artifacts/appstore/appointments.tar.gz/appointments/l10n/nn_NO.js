OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Avbryt",
    "Info" : "Info",
    "Close" : "Lukk",
    "Remove" : "Fjern",
    "Start" : "Start",
    "Apply" : "Anvend",
    "Deleted" : "Sletta",
    "Confirmed" : "Stadfesta",
    "Error" : "Feil",
    "Warning" : "Åtvaring",
    "Back" : "Tilbake",
    "Next" : "Neste",
    "An error has occurred" : "Ein feil har oppstått"
},
"nplurals=2; plural=(n != 1);");
