OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потвърди",
    "Cancel" : "Отказ",
    "Info" : "Информация",
    "Email" : "Имейл",
    "Close" : "Затваряне",
    "Copy public link" : "Копирай публичната връзка",
    "Address" : "Адрес",
    "Apply" : "Приложи",
    "Start" : "Начало"
},
"nplurals=2; plural=(n != 1);");
