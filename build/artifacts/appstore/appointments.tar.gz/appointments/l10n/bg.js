OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потвърди",
    "Cancel" : "Отказ",
    "Info" : "Информация",
    "Available" : "Налични",
    "Close" : "Затваряне",
    "Remove" : "Премахни",
    "Copy public link" : "Копирай публичната връзка",
    "Start" : "Начало",
    "Apply" : "Приложи",
    "Deleted" : "Изтрито",
    "Confirmed" : "Потвърдено",
    "Location:" : "Местоположение:",
    "Back" : "Назад",
    "Next" : "Напред",
    "An error has occurred" : "Възникна грешка"
},
"nplurals=2; plural=(n != 1);");
