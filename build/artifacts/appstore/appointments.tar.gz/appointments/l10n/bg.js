OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потвърди",
    "Cancel" : "Отказ",
    "Info" : "Информация",
    "Close" : "Затваряне",
    "Copy public link" : "Копирай публичната връзка",
    "Apply" : "Приложи",
    "Start" : "Начало"
},
"nplurals=2; plural=(n != 1);");
