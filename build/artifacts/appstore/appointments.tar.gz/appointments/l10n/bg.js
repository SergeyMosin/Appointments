OC.L10N.register(
    "appointments",
    {
    "Available" : "Налични",
    "Confirm" : "Потвърди",
    "Cancel" : "Отказ",
    "Info" : "Информация",
    "Close" : "Затваряне",
    "Remove" : "Премахни",
    "Warning" : "Внимание",
    "Start" : "Начало",
    "Apply" : "Приложи",
    "Deleted" : "Изтрито",
    "Confirmed" : "Потвърдено",
    "Advanced Settings" : "Допълнителни настройки",
    "Error" : "Грешка",
    "Location:" : "Местоположение:",
    "Back" : "Назад",
    "Next" : "Напред",
    "An error has occurred" : "Възникна грешка"
},
"nplurals=2; plural=(n != 1);");
