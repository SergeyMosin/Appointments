OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потвърди",
    "Cancel" : "Отказ",
    "Info" : "Информация",
    "Available" : "Налични",
    "Close" : "Затваряне",
    "Copy public link" : "Копирай публичната връзка",
    "Apply" : "Приложи",
    "Deleted" : "Изтрито",
    "Confirmed" : "Потвърдено",
    "Start" : "Начало",
    "Location:" : "Местоположение:"
},
"nplurals=2; plural=(n != 1);");
