OC.L10N.register(
    "appointments",
    {
    "Cancel" : "বাতির",
    "Info" : "Info",
    "Close" : "বন্ধ",
    "Deleted" : "মুছে ফেলা",
    "Location:" : "অবস্থান:",
    "Back" : "পেছনে যাও",
    "Next" : "পরবর্তী"
},
"nplurals=2; plural=(n != 1);");
