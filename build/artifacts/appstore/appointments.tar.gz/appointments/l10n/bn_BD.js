OC.L10N.register(
    "appointments",
    {
    "Cancel" : "বাতির",
    "Info" : "Info",
    "Email" : "ইমেইল",
    "Close" : "বন্ধ",
    "Address" : "ঠিকানা"
},
"nplurals=2; plural=(n != 1);");
