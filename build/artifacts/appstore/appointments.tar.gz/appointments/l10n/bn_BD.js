OC.L10N.register(
    "appointments",
    {
    "Cancel" : "বাতির",
    "Info" : "Info",
    "Close" : "বন্ধ",
    "Remove" : "অপসারণ",
    "Warning" : "সতর্কবাণী",
    "Deleted" : "মুছে ফেলা",
    "Error" : "সমস্যা",
    "Location:" : "অবস্থান:",
    "Back" : "পেছনে যাও",
    "Next" : "পরবর্তী"
},
"nplurals=2; plural=(n != 1);");
