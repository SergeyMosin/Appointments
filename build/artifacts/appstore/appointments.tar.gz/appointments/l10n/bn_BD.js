OC.L10N.register(
    "appointments",
    {
    "Cancel" : "বাতির",
    "Info" : "Info",
    "Close" : "বন্ধ",
    "Remove" : "অপসারণ",
    "Warning" : "সতর্কবাণী",
    "Deleted" : "মুছে ফেলা",
    "15 Minutes" : "15 Minutes",
    "30 Minutes" : "30 Minutes",
    "1 Hour" : "1 Hour",
    "2 Hours" : "2 Hours",
    "Error" : "সমস্যা",
    "Location:" : "অবস্থান:",
    "Back" : "পেছনে যাও",
    "Next" : "পরবর্তী"
},
"nplurals=2; plural=(n != 1);");
