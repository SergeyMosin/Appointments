OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Anullar",
    "Info" : "Info",
    "Close" : "Tampar",
    "Remove" : "Suprimir",
    "Apply" : "Aplicar",
    "Deleted" : "Suprimit",
    "15 Minutes" : "15 Minutas",
    "30 Minutes" : "30 Minutas",
    "1 Hour" : "1 Ora",
    "2 Hours" : "2 Oras",
    "Simple" : "Simpla",
    "Error" : "Error",
    "Warning" : "Atencion",
    "Location:" : "Localizacion :",
    "Back" : "Retorn",
    "Next" : "Seguent"
},
"nplurals=2; plural=(n > 1);");
