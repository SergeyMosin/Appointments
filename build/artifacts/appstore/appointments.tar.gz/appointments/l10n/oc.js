OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Anullar",
    "Info" : "Info",
    "Close" : "Tampar",
    "Remove" : "Suprimir",
    "Apply" : "Aplicar",
    "Deleted" : "Suprimit",
    "Location:" : "Localizacion :",
    "Back" : "Retorn",
    "Next" : "Seguent"
},
"nplurals=2; plural=(n > 1);");
