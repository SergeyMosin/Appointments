OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Anullar",
    "Info" : "Info",
    "Email" : "Adreça corrièl",
    "Close" : "Tampar",
    "Address" : "Adreça",
    "Apply" : "Aplicar"
},
"nplurals=2; plural=(n > 1);");
