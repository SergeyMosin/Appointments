OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Anullar",
    "Info" : "Info",
    "Close" : "Tampar",
    "Apply" : "Aplicar",
    "Deleted" : "Suprimit",
    "Location:" : "Localizacion :"
},
"nplurals=2; plural=(n > 1);");
