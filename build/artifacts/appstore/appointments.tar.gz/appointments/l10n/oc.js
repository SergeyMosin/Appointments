OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Anullar",
    "Info" : "Info",
    "Close" : "Tampar",
    "Remove" : "Suprimir",
    "Warning" : "Atencion",
    "Apply" : "Aplicar",
    "Deleted" : "Suprimit",
    "Simple" : "Simpla",
    "Error" : "Error",
    "Location:" : "Localizacion :",
    "Back" : "Retorn",
    "Next" : "Seguent"
},
"nplurals=2; plural=(n > 1);");
