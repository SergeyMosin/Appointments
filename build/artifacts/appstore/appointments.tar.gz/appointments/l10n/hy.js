OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ընդհատել",
    "Password" : "Գաղտնաբառ",
    "Info" : "Info",
    "Delete" : "հեռացնել",
    "Settings" : "կարգավորումներ",
    "Close" : "Փակել",
    "Save" : "Պահպանել",
    "Loading" : "Loading",
    "Edit" : "մշակել",
    "Title" : "Վերնագիր",
    "URL" : "URL",
    "Error" : "Սխալ",
    "Deleted" : "Ջնջված",
    "Confirmed" : "Հաստատված",
    "Warning" : "Զգուշացում",
    "Next" : "Հաջորդ"
},
"nplurals=2; plural=(n != 1);");
