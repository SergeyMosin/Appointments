OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ընդհատել",
    "Info" : "Info",
    "Email" : "Էլ․փոստ",
    "Close" : "Փակել",
    "Address" : "Հասցե"
},
"nplurals=2; plural=(n != 1);");
