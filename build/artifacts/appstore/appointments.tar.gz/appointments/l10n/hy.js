OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ընդհատել",
    "Password" : "Գաղտնաբառ",
    "Info" : "Info",
    "Delete" : "հեռացնել",
    "Settings" : "կարգավորումներ",
    "Close" : "Փակել",
    "Loading" : "Loading",
    "Warning" : "Զգուշացում",
    "Error" : "Սխալ",
    "Edit" : "մշակել",
    "Title" : "Վերնագիր",
    "URL" : "URL",
    "Save" : "Պահպանել",
    "Deleted" : "Ջնջված",
    "Confirmed" : "Հաստատված",
    "Next" : "Հաջորդ"
},
"nplurals=2; plural=(n != 1);");
