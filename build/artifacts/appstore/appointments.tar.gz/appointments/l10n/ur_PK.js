OC.L10N.register(
    "appointments",
    {
    "Cancel" : "منسوخ کریں",
    "Info" : "Info",
    "Delete" : "حذف کریں",
    "Settings" : "سیٹینگز",
    "Close" : "بند ",
    "Loading" : "Loading",
    "Warning" : "انتباہ",
    "Error" : "ایرر",
    "Edit" : "تدوین کریں",
    "Title" : "عنوان",
    "URL" : "یو ار ایل",
    "Save" : "حفظ",
    "Deleted" : "حذف شدہ ",
    "Next" : "اگلا"
},
"nplurals=2; plural=(n != 1);");
