OC.L10N.register(
    "appointments",
    {
    "Cancel" : "منسوخ کریں",
    "Password" : "پاسورڈ",
    "Info" : "Info",
    "Delete" : "حذف کریں",
    "Settings" : "سیٹینگز",
    "Close" : "بند ",
    "Save" : "حفظ",
    "Loading" : "Loading",
    "Add" : "شامل کریں",
    "OK" : "اوکے",
    "Edit" : "تدوین کریں",
    "Title" : "عنوان",
    "URL" : "یو ار ایل",
    "Error" : "ایرر",
    "Deleted" : "حذف شدہ ",
    "Warning" : "انتباہ",
    "Next" : "اگلا",
    "Email" : "email"
},
"nplurals=2; plural=(n != 1);");
