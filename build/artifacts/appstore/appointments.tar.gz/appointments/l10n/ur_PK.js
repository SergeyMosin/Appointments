OC.L10N.register(
    "appointments",
    {
    "Cancel" : "منسوخ کریں",
    "Password" : "پاسورڈ",
    "Info" : "Info",
    "Delete" : "حذف کریں",
    "Settings" : "سیٹینگز",
    "Close" : "بند ",
    "Save" : "حفظ",
    "Loading" : "Loading",
    "Edit" : "تدوین کریں",
    "Title" : "عنوان",
    "URL" : "یو ار ایل",
    "Error" : "ایرر",
    "Deleted" : "حذف شدہ ",
    "Warning" : "انتباہ",
    "Next" : "اگلا"
},
"nplurals=2; plural=(n != 1);");
