OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekræft",
    "Cancel" : "Annullér",
    "Info" : "Info",
    "Email" : "Email",
    "Close" : "Luk",
    "Copy public link" : "Kopier offentligt link",
    "Address" : "Adresse",
    "Apply" : "Anvend",
    "Start" : "Start",
    "close" : "luk"
},
"nplurals=2; plural=(n != 1);");
