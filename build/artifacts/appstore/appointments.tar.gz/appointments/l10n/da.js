OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekræft",
    "Cancel" : "Annullér",
    "Info" : "Info",
    "Close" : "Luk",
    "Copy public link" : "Kopier offentligt link",
    "Apply" : "Anvend",
    "Deleted" : "Slettet",
    "Confirmed" : "Bekræftet",
    "Start" : "Start",
    "close" : "luk",
    "Location:" : "Sted:"
},
"nplurals=2; plural=(n != 1);");
