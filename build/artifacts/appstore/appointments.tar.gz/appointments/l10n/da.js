OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekræft",
    "Cancel" : "Annullér",
    "Info" : "Info",
    "Close" : "Luk",
    "Copy public link" : "Kopier offentligt link",
    "Apply" : "Anvend",
    "Deleted" : "Slettet",
    "Confirmed" : "Bekræftet",
    "Start" : "Start",
    "close" : "luk",
    "Location:" : "Sted:",
    "Back" : "Tilbage",
    "Next" : "Næste",
    "An error has occurred" : "Der opstod en fejl."
},
"nplurals=2; plural=(n != 1);");
