OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekræft",
    "Cancel" : "Annullér",
    "Info" : "Info",
    "Close" : "Luk",
    "Remove" : "Fjern",
    "Warning" : "Advarsel",
    "Start" : "Start",
    "Apply" : "Anvend",
    "Deleted" : "Slettet",
    "Confirmed" : "Bekræftet",
    "close" : "luk",
    "Simple" : "Simpel",
    "Error" : "Fejl",
    "Location:" : "Sted:",
    "Back" : "Tilbage",
    "Next" : "Næste",
    "An error has occurred" : "Der opstod en fejl."
},
"nplurals=2; plural=(n != 1);");
