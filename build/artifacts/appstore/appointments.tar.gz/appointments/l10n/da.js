OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Bekræft",
    "Cancel" : "Annullér",
    "Info" : "Info",
    "Close" : "Luk",
    "Copy public link" : "Kopier offentligt link",
    "Apply" : "Anvend",
    "Start" : "Start",
    "close" : "luk"
},
"nplurals=2; plural=(n != 1);");
