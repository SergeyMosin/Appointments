OC.L10N.register(
    "appointments",
    {
    "Available" : "Достапно",
    "Confirm" : "Потврди",
    "Cancel" : "Откажи",
    "Info" : "Info",
    "Close" : "Затвори",
    "Remove" : "Отстрани",
    "Start" : "Почеток",
    "Advanced Settings" : "Напредни параметри",
    "Apply" : "Примени",
    "Warning" : "Предупредување",
    "Error" : "Грешка",
    "Deleted" : "Избришана",
    "Confirmed" : "Потврдено",
    "Name:" : "Име:",
    "Location:" : "Локација:",
    "Back" : "Назад",
    "Next" : "Следно"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
