OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потврди",
    "Cancel" : "Откажи",
    "Info" : "Info",
    "Available" : "Достапно",
    "Close" : "Затвори",
    "Remove" : "Отстрани",
    "Copy public link" : "Копирај јавен линк",
    "Start" : "Почеток",
    "Apply" : "Примени",
    "Deleted" : "Избришана",
    "Confirmed" : "Потврдено",
    "Advanced Settings" : "Напредни параметри",
    "Location:" : "Локација:",
    "Back" : "Назад",
    "Next" : "Следно"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
