OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потврди",
    "Cancel" : "Откажи",
    "Info" : "Info",
    "Email" : "Е-пошта",
    "Close" : "Затвори",
    "Copy public link" : "Копирај јавен линк",
    "Address" : "Адреса",
    "Apply" : "Примени",
    "Start" : "Почеток"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
