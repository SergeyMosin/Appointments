OC.L10N.register(
    "appointments",
    {
    "Available" : "Достапно",
    "Confirm" : "Потврди",
    "Cancel" : "Откажи",
    "Info" : "Info",
    "Close" : "Затвори",
    "Remove" : "Отстрани",
    "Warning" : "Предупредување",
    "Start" : "Почеток",
    "Apply" : "Примени",
    "Deleted" : "Избришана",
    "Confirmed" : "Потврдено",
    "Advanced Settings" : "Напредни параметри",
    "Error" : "Грешка",
    "Name:" : "Име:",
    "Location:" : "Локација:",
    "Back" : "Назад",
    "Next" : "Следно"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
