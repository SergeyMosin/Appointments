OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Потврди",
    "Cancel" : "Откажи",
    "Info" : "Info",
    "Close" : "Затвори",
    "Copy public link" : "Копирај јавен линк",
    "Apply" : "Примени",
    "Start" : "Почеток"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
