OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmo",
    "Cancel" : "Anullo",
    "Info" : "Info",
    "Close" : "Mbylleni",
    "Remove" : "Hiq",
    "Start" : "Fillo",
    "Apply" : "Apliko",
    "Deleted" : "E fshirë",
    "Confirmed" : "E konfirmuar",
    "close" : "mbyll",
    "Location:" : "Vendndodhje:",
    "Back" : "Prapa",
    "Next" : "Tjetër",
    "An error has occurred" : "Ka ndodhur një gabim"
},
"nplurals=2; plural=(n != 1);");
