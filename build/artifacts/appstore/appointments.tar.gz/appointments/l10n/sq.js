OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Konfirmo",
    "Cancel" : "Anullo",
    "Info" : "Info",
    "Close" : "Mbylleni",
    "Apply" : "Apliko",
    "Start" : "Fillo",
    "close" : "mbyll"
},
"nplurals=2; plural=(n != 1);");
