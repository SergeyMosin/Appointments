OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Potrdi",
    "Cancel" : "Prekliči",
    "Info" : "Podrobnosti",
    "Email" : "Elektronski naslov",
    "Close" : "Zapri",
    "Copy public link" : "Kopiraj javno povezavo",
    "Address" : "Naslov",
    "Apply" : "Uveljavi",
    "Start" : "Začni",
    "close" : "zapri"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
