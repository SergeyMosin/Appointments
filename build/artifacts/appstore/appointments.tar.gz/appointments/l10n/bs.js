OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Otkaži",
    "Info" : "Info",
    "Delete" : "Obriši",
    "Settings" : "Podešavanje",
    "Close" : "Zatvori",
    "Loading" : "Loading",
    "Warning" : "Upozorenje",
    "Error" : "Greška",
    "Edit" : "Izmjeni",
    "Title" : "Naslov",
    "URL" : "Url",
    "Save" : "Spremi",
    "Next" : "Sljedeće"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
