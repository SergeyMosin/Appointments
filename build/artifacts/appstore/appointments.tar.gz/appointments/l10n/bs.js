OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Otkaži",
    "Password" : "Lozinka",
    "Info" : "Info",
    "Settings" : "Podešavanje",
    "Title" : "Naslov",
    "URL" : "Url",
    "Save" : "Spremi",
    "Add" : "Dodaj",
    "OK" : "OK",
    "Delete" : "Obriši",
    "Location" : "Lokacija",
    "Phone" : "Telefon",
    "Warning" : "Upozorenje",
    "Advanced" : "Napredno",
    "Edit" : "Izmjeni",
    "Next" : "Sljedeće",
    "Full Name" : "Puno ime",
    "Email" : "E-pošta"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
