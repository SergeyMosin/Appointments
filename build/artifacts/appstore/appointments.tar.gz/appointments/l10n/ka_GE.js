OC.L10N.register(
    "appointments",
    {
    "Confirm" : "დადასტურება",
    "Cancel" : "უარყოფა",
    "Info" : "ინფორმაცია",
    "Email" : "ელ-ფოსტა",
    "Close" : "დახურვა",
    "Address" : "მისამართი",
    "Apply" : "გამოყენება",
    "Start" : "დაწყება"
},
"nplurals=2; plural=(n!=1);");
