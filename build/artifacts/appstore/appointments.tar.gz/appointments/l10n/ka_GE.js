OC.L10N.register(
    "appointments",
    {
    "Confirm" : "დადასტურება",
    "Cancel" : "უარყოფა",
    "Info" : "ინფორმაცია",
    "Close" : "დახურვა",
    "Remove" : "წაშლა",
    "Warning" : "გაფრთხილება",
    "Start" : "დაწყება",
    "Apply" : "გამოყენება",
    "Deleted" : "გაუქმდა",
    "Confirmed" : "დადასტურებლია",
    "Simple" : "მარტივი",
    "Error" : "შეცდომა",
    "Location:" : "ადგილმდებარეობა:",
    "Back" : "უკან",
    "Next" : "შემდეგი",
    "An error has occurred" : "წარმოიშვა შეცდომა"
},
"nplurals=2; plural=(n!=1);");
