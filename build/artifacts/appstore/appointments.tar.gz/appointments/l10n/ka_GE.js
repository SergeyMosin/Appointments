OC.L10N.register(
    "appointments",
    {
    "Confirm" : "დადასტურება",
    "Cancel" : "უარყოფა",
    "Info" : "ინფორმაცია",
    "Close" : "დახურვა",
    "Apply" : "გამოყენება",
    "Start" : "დაწყება"
},
"nplurals=2; plural=(n!=1);");
