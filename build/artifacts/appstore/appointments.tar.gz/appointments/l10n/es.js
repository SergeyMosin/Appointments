OC.L10N.register(
    "appointments",
    {
    "%s Appointment is Confirmed" : "%s Cita está Confirmada",
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Información",
    "Email" : "Correo electrónico",
    "Add to Calendar" : "Añadir al Calendario",
    "Close" : "Cerrar",
    "Copy public link" : "Copiar enlace público",
    "Address" : "Dirección",
    "Apply" : "Aplicar",
    "Start" : "Iniciar",
    "close" : "cerrar",
    "Name:" : "Nombre:"
},
"nplurals=2; plural=(n != 1);");
