OC.L10N.register(
    "appointments",
    {
    "Confirm" : "אימות",
    "Cancel" : "ביטול",
    "Info" : "פרטים",
    "Email" : "דוא״ל",
    "Close" : "סגור",
    "Address" : "כתובת",
    "Apply" : "החלה",
    "Start" : "התחלה"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
