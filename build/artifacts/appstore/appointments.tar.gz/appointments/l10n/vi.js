OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Xác nhận",
    "Cancel" : "Hủy bỏ",
    "Info" : "Info",
    "Email" : "Thư điện tử",
    "Close" : "Đóng",
    "Address" : "Địa chỉ",
    "Apply" : "Áp dụng",
    "Start" : "Bắt đầu"
},
"nplurals=1; plural=0;");
