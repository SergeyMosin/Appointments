OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Megerősít",
    "Cancel" : "Mégse",
    "Info" : "Infó",
    "Email" : "E-mail",
    "Close" : "Bezár",
    "Address" : "Cím",
    "Apply" : "Alkalmaz",
    "Start" : "Indítás",
    "close" : "bezárás"
},
"nplurals=2; plural=(n != 1);");
