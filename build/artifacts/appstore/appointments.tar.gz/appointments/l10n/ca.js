OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirma",
    "Cancel" : "Cancel·la",
    "Info" : "Info",
    "Email" : "Correu",
    "Close" : "Tanca",
    "Address" : "Adreça",
    "Apply" : "Aplica",
    "Start" : "Inici",
    "close" : "tanca"
},
"nplurals=2; plural=(n != 1);");
