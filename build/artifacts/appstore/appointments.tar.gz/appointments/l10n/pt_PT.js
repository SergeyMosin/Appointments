OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Informação",
    "Close" : "Fechar",
    "Apply" : "Aplicar",
    "Deleted" : "Eliminado",
    "Confirmed" : "Confirmado",
    "Start" : "Início",
    "close" : "fechar",
    "Location:" : "Localização:",
    "Back" : "Anterior",
    "Next" : "Próximo",
    "An error has occurred" : "Ocorreu um erro"
},
"nplurals=2; plural=(n != 1);");
