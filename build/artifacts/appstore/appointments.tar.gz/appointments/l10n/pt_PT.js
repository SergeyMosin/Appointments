OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Informação",
    "Close" : "Fechar",
    "Remove" : "Remover",
    "Warning" : "Aviso",
    "Start" : "Início",
    "Apply" : "Aplicar",
    "Deleted" : "Eliminado",
    "Confirmed" : "Confirmado",
    "close" : "fechar",
    "Simple" : "Simples",
    "Error" : "Erro",
    "Location:" : "Localização:",
    "Back" : "Anterior",
    "Next" : "Próximo",
    "An error has occurred" : "Ocorreu um erro"
},
"nplurals=2; plural=(n != 1);");
