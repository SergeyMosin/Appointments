OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Informação",
    "Close" : "Fechar",
    "Apply" : "Aplicar",
    "Start" : "Início",
    "close" : "fechar"
},
"nplurals=2; plural=(n != 1);");
