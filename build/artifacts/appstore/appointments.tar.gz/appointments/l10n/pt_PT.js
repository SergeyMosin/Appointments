OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Informação",
    "Email" : "Email",
    "Close" : "Fechar",
    "Address" : "Morada",
    "Apply" : "Aplicar",
    "Start" : "Início",
    "close" : "fechar"
},
"nplurals=2; plural=(n != 1);");
