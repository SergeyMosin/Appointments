OC.L10N.register(
    "appointments",
    {
    "Confirm" : "تأكيد",
    "Cancel" : "إلغاء",
    "Info" : "Info",
    "Available" : "متوفرة",
    "Close" : "إغلاق",
    "Remove" : "حذف",
    "Deleted" : "تم حذفه",
    "Confirmed" : "مؤكَّد",
    "close" : "إغلاق",
    "Location:" : "المكان :",
    "Back" : "العودة",
    "Next" : "التالي"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
