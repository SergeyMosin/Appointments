OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancellar",
    "Info" : "Info",
    "Delete" : "Deler",
    "Settings" : "Configurationes",
    "Close" : "Clauder",
    "Loading" : "Loading",
    "Start" : "Initio",
    "Apply" : "Applicar",
    "Warning" : "Aviso",
    "Error" : "Error",
    "Edit" : "Modificar",
    "Title" : "Titulo",
    "URL" : "URL",
    "Save" : "Salveguardar",
    "Deleted" : "Delite",
    "Confirmed" : "Confirmate",
    "Back" : "Retro",
    "Next" : "Sequente"
},
"nplurals=2; plural=(n != 1);");
