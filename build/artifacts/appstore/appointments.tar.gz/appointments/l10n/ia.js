OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancellar",
    "Info" : "Info",
    "Email" : "E-posta",
    "Close" : "Clauder",
    "Address" : "Adresse",
    "Apply" : "Applicar",
    "Start" : "Initio"
},
"nplurals=2; plural=(n != 1);");
