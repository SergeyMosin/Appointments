OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancellar",
    "Info" : "Info",
    "Close" : "Clauder",
    "Apply" : "Applicar",
    "Deleted" : "Delite",
    "Confirmed" : "Confirmate",
    "Start" : "Initio"
},
"nplurals=2; plural=(n != 1);");
