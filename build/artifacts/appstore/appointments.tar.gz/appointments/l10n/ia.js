OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancellar",
    "Info" : "Info",
    "Close" : "Clauder",
    "Apply" : "Applicar",
    "Start" : "Initio"
},
"nplurals=2; plural=(n != 1);");
