OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Sguir dheth",
    "Password" : "Facal-faire",
    "Delete" : "Sguab às",
    "Settings" : "Roghainnean",
    "Close" : "Dùin",
    "Remove" : "Thoir air falbh",
    "Save" : "Sàbhail",
    "Preview" : "Ro-sheall",
    "OK" : "Ceart ma-thà",
    "30 minutes" : "Leth-uair a thìde",
    "1 hour" : "Uair a thìde",
    "4 hours" : "4 uairean a thìde",
    "Loading…" : "’Ga luchdadh…",
    "Edit" : "Deasaich",
    "Error" : "Mearachd",
    "Deleted" : "Chaidh a sguabadh às",
    "Location:" : "Ionad:",
    "Back" : "Air ais",
    "Email" : "Post-d"
},
"nplurals=4; plural=(n==1 || n==11) ? 0 : (n==2 || n==12) ? 1 : (n > 2 && n < 20) ? 2 : 3;");
