OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirm",
    "Cancel" : "Cancel",
    "Password" : "Password",
    "Delete" : "Delete",
    "Settings" : "Settings",
    "Close" : "Close",
    "Remove" : "Remove",
    "Save" : "Save",
    "Loading" : "Loading",
    "Add" : "Add",
    "OK" : "OK",
    "30 minutes" : "30 minutes",
    "1 hour" : "1 hour",
    "4 hours" : "4 hours",
    "12 hours" : "12 hours",
    "Loading…" : "Loading…",
    "Error" : "Error",
    "Minutes" : "Minutes",
    "Name" : "Name"
},
"nplurals=1; plural=0;");
