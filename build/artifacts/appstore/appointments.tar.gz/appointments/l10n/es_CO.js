OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Info",
    "Close" : "Cerrar",
    "Remove" : "Eliminar",
    "Start" : "Iniciar",
    "Apply" : "Aplicar",
    "Deleted" : "Borrado",
    "Confirmed" : "Confirmado",
    "close" : "Cerrar",
    "Location:" : "Ubicación:",
    "Back" : "Atrás",
    "Next" : "Siguiente",
    "An error has occurred" : "Se presentó un error"
},
"nplurals=2; plural=(n != 1);");
