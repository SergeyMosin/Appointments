OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Info",
    "Close" : "Cerrar",
    "Remove" : "Eliminar",
    "Warning" : "Advertencia",
    "Start" : "Iniciar",
    "Apply" : "Aplicar",
    "Deleted" : "Borrado",
    "Confirmed" : "Confirmado",
    "close" : "Cerrar",
    "Simple" : "Simple",
    "Error" : "Error",
    "Location:" : "Ubicación:",
    "Back" : "Atrás",
    "Next" : "Siguiente",
    "An error has occurred" : "Se presentó un error"
},
"nplurals=2; plural=(n != 1);");
