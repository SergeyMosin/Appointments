OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Batal",
    "Password" : "Kata laluan",
    "Info" : "Info",
    "Delete" : "Padam",
    "Settings" : "Tetapan",
    "Close" : "Tutup",
    "Remove" : "Buang",
    "Save" : "Simpan",
    "Loading" : "Loading",
    "Warning" : "Amaran",
    "Error" : "Ralat",
    "Edit" : "Sunting",
    "Title" : "Judul",
    "URL" : "URL",
    "Deleted" : "Dipadam",
    "Back" : "Kembali",
    "Next" : "Seterus"
},
"nplurals=1; plural=0;");
