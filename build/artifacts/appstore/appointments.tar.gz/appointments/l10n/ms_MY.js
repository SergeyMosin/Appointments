OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Batal",
    "Password" : "Kata laluan",
    "Info" : "Info",
    "Delete" : "Padam",
    "Settings" : "Tetapan",
    "Close" : "Tutup",
    "Remove" : "Buang",
    "Save" : "Simpan",
    "Loading" : "Loading",
    "Edit" : "Sunting",
    "Title" : "Judul",
    "URL" : "URL",
    "Error" : "Ralat",
    "Deleted" : "Dipadam",
    "Warning" : "Amaran",
    "Back" : "Kembali",
    "Next" : "Seterus"
},
"nplurals=1; plural=0;");
