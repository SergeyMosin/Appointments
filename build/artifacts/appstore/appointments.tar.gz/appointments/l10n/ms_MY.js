OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Batal",
    "Info" : "Info",
    "Close" : "Tutup",
    "Remove" : "Buang",
    "Warning" : "Amaran",
    "Deleted" : "Dipadam",
    "Error" : "Ralat",
    "Back" : "Kembali",
    "Next" : "Seterus"
},
"nplurals=1; plural=0;");
