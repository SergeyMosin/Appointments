OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Batal",
    "Info" : "Info",
    "Delete" : "Padam",
    "Settings" : "Tetapan",
    "Close" : "Tutup",
    "Remove" : "Buang",
    "Loading" : "Loading",
    "Warning" : "Amaran",
    "Error" : "Ralat",
    "Edit" : "Sunting",
    "Title" : "Judul",
    "URL" : "URL",
    "Save" : "Simpan",
    "Deleted" : "Dipadam",
    "Back" : "Kembali",
    "Next" : "Seterus"
},
"nplurals=1; plural=0;");
