OC.L10N.register(
    "appointments",
    {
    "Cancel" : "Batal",
    "Info" : "Info",
    "Email" : "Email",
    "Close" : "Tutup",
    "Address" : "Alamat"
},
"nplurals=1; plural=0;");
