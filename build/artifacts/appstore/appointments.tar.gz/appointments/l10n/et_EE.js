OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Kinnita",
    "Cancel" : "Loobu",
    "Info" : "Info",
    "Close" : "Sulge",
    "Copy public link" : "Kopeeri avalik link",
    "Apply" : "Rakenda",
    "Start" : "Algus"
},
"nplurals=2; plural=(n != 1);");
