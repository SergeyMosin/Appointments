OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Kinnita",
    "Cancel" : "Loobu",
    "Info" : "Info",
    "Close" : "Sulge",
    "Copy public link" : "Kopeeri avalik link",
    "Apply" : "Rakenda",
    "Deleted" : "Kustutatud",
    "Confirmed" : "Kinnitatud",
    "Start" : "Algus",
    "Location:" : "Asukoht:"
},
"nplurals=2; plural=(n != 1);");
