OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Kinnita",
    "Cancel" : "Loobu",
    "Info" : "Info",
    "Email" : "Epost",
    "Close" : "Sulge",
    "Address" : "Aadress",
    "Apply" : "Rakenda",
    "Start" : "Algus"
},
"nplurals=2; plural=(n != 1);");
