OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Kinnita",
    "Cancel" : "Loobu",
    "Info" : "Info",
    "Email" : "Epost",
    "Close" : "Sulge",
    "Copy public link" : "Kopeeri avalik link",
    "Address" : "Aadress",
    "Apply" : "Rakenda",
    "Start" : "Algus"
},
"nplurals=2; plural=(n != 1);");
