OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Kinnita",
    "Cancel" : "Loobu",
    "Info" : "Info",
    "Close" : "Sulge",
    "Remove" : "Eemalda",
    "Start" : "Algus",
    "Apply" : "Rakenda",
    "Deleted" : "Kustutatud",
    "Confirmed" : "Kinnitatud",
    "15 Minutes" : "15 minutit",
    "30 Minutes" : "30 minutit",
    "1 Hour" : "1 tund",
    "2 Hours" : "2 tundi",
    "Error" : "Viga",
    "Warning" : "Hoiatus",
    "Location:" : "Asukoht:",
    "Back" : "Tagasi",
    "Next" : "Järgmine",
    "An error has occurred" : "Tekkis tõrge"
},
"nplurals=2; plural=(n != 1);");
