OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Kinnita",
    "Cancel" : "Loobu",
    "Info" : "Info",
    "Close" : "Sulge",
    "Copy public link" : "Kopeeri avalik link",
    "Apply" : "Rakenda",
    "Deleted" : "Kustutatud",
    "Confirmed" : "Kinnitatud",
    "Start" : "Algus",
    "Location:" : "Asukoht:",
    "Back" : "Tagasi",
    "Next" : "Järgmine",
    "An error has occurred" : "Tekkis tõrge"
},
"nplurals=2; plural=(n != 1);");
