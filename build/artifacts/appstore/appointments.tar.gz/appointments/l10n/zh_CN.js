OC.L10N.register(
    "appointments",
    {
    "Confirm" : "确认",
    "Cancel" : "取消",
    "Info" : "信息",
    "Email" : "电子邮箱",
    "Close" : "关闭",
    "Copy public link" : "复制公开链接",
    "Address" : "地址",
    "Apply" : "应用",
    "Timezone:" : "时区：",
    "Start" : "起点",
    "close" : "关闭"
},
"nplurals=1; plural=0;");
