OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ยกเลิก",
    "Info" : "Info",
    "Email" : "อีเมล",
    "Close" : "ปิด",
    "Address" : "ที่อยู่",
    "Apply" : "นำไปใช้"
},
"nplurals=1; plural=0;");
