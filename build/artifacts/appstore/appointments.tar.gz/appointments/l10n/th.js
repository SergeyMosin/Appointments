OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ยกเลิก",
    "Info" : "Info",
    "Close" : "ปิด",
    "Remove" : "ลบออก",
    "Warning" : "คำเตือน",
    "Apply" : "นำไปใช้",
    "Deleted" : "ลบแล้ว",
    "Confirmed" : "ได้รับการยืนยันแล้ว",
    "Simple" : "ปกติ",
    "Error" : "ข้อผิดพลาด",
    "Location:" : "สถานที่ตั้ง:",
    "Back" : "ย้อนกลับ",
    "Next" : "ถัดไป"
},
"nplurals=1; plural=0;");
