OC.L10N.register(
    "appointments",
    {
    "Cancel" : "ยกเลิก",
    "Info" : "Info",
    "Close" : "ปิด",
    "Remove" : "ลบออก",
    "Apply" : "นำไปใช้",
    "Deleted" : "ลบแล้ว",
    "Confirmed" : "ได้รับการยืนยันแล้ว",
    "Location:" : "สถานที่ตั้ง:",
    "Back" : "ย้อนกลับ",
    "Next" : "ถัดไป"
},
"nplurals=1; plural=0;");
