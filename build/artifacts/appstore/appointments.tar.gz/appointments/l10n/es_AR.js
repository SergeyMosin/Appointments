OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Info",
    "Close" : "Cerrar",
    "Apply" : "Aplicar",
    "Start" : "Inicio"
},
"nplurals=2; plural=(n != 1);");
