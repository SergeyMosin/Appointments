OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Info",
    "Close" : "Cerrar",
    "Remove" : "Borrar",
    "Warning" : "Advertencia",
    "Start" : "Inicio",
    "Apply" : "Aplicar",
    "Deleted" : "Borrado",
    "Confirmed" : "Confirmado",
    "Error" : "Error",
    "Location:" : "Ubicación:",
    "Back" : "Atrás",
    "Next" : "Siguiente",
    "An error has occurred" : "Se ha presentado un error"
},
"nplurals=2; plural=(n != 1);");
