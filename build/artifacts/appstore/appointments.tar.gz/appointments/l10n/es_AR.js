OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Info",
    "Close" : "Cerrar",
    "Remove" : "Borrar",
    "Copy public link" : "Copiar link publico",
    "Start" : "Inicio",
    "Apply" : "Aplicar",
    "Deleted" : "Borrado",
    "Confirmed" : "Confirmado",
    "Location:" : "Ubicación:",
    "Back" : "Atrás",
    "Next" : "Siguiente",
    "An error has occurred" : "Se ha presentado un error"
},
"nplurals=2; plural=(n != 1);");
