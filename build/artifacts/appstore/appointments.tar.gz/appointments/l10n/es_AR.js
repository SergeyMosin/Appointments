OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Confirmar",
    "Cancel" : "Cancelar",
    "Info" : "Info",
    "Close" : "Cerrar",
    "Copy public link" : "Copiar link publico",
    "Apply" : "Aplicar",
    "Deleted" : "Borrado",
    "Confirmed" : "Confirmado",
    "Start" : "Inicio",
    "Location:" : "Ubicación:",
    "Back" : "Atrás",
    "Next" : "Siguiente",
    "An error has occurred" : "Se ha presentado un error"
},
"nplurals=2; plural=(n != 1);");
