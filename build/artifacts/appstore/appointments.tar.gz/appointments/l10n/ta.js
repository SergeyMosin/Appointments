OC.L10N.register(
    "appointments",
    {
    "Cancel" : "இரத்து செய்க",
    "Password" : "கடவுச்சொல்",
    "Info" : "Info",
    "Settings" : "அமைப்புகள்",
    "Title" : "தலைப்பு",
    "URL" : "URL",
    "Save" : "சேமிக்க ",
    "Remove" : "அகற்றுக",
    "Add" : "சேர்க்க",
    "OK" : "சரி ",
    "Delete" : "நீக்குக",
    "Location" : "இடம்",
    "Phone" : "தொலைப்பேசி",
    "Warning" : "எச்சரிக்கை",
    "Advanced" : "உயர்ந்த",
    "Edit" : "தொகுக்க",
    "Back" : "பின்னுக்கு",
    "Next" : "அடுத்த",
    "Email" : "மின்னஞ்சல்"
},
"nplurals=2; plural=(n != 1);");
