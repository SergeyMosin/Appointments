OC.L10N.register(
    "appointments",
    {
    "Cancel" : "取消",
    "Password" : "密碼",
    "Info" : "Info",
    "Delete" : "刪除",
    "Settings" : "設定",
    "Close" : "關閉",
    "Remove" : "刪除",
    "Loading" : "Loading",
    "Apply" : "套用",
    "Warning" : "警告",
    "Error" : "錯誤",
    "Edit" : "編輯",
    "Title" : "標題",
    "URL" : "網址",
    "Save" : "儲存",
    "Back" : "返回",
    "Next" : "下一首"
},
"nplurals=1; plural=0;");
