OC.L10N.register(
    "appointments",
    {
    "Cancel" : "取消",
    "Info" : "Info",
    "Email" : "電郵",
    "Close" : "關閉",
    "Address" : "地址",
    "Apply" : "套用"
},
"nplurals=1; plural=0;");
