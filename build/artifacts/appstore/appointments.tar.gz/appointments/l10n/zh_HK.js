OC.L10N.register(
    "appointments",
    {
    "Cancel" : "取消",
    "Info" : "Info",
    "Close" : "關閉",
    "Remove" : "刪除",
    "Warning" : "警告",
    "Apply" : "套用",
    "Error" : "錯誤",
    "Back" : "返回",
    "Next" : "下一首"
},
"nplurals=1; plural=0;");
