OC.L10N.register(
    "appointments",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Info" : "Info",
    "Email" : "﻿ಇ-ಅಂಚೆ",
    "Close" : "ಮುಚ್ಚು",
    "Address" : "ವಿಳಾಸ"
},
"nplurals=2; plural=(n > 1);");
