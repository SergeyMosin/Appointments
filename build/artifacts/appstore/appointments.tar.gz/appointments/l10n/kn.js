OC.L10N.register(
    "appointments",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Info" : "Info",
    "Delete" : "﻿ಅಳಿಸಿ",
    "Settings" : "ಆಯ್ಕೆ",
    "Close" : "ಮುಚ್ಚು",
    "Remove" : "ತೆಗೆದುಹಾಕಿ",
    "Save" : "﻿ಉಳಿಸಿ",
    "Loading" : "Loading",
    "Add" : "﻿ಸೇರಿಸಿ",
    "OK" : "ಸರಿ",
    "Edit" : "ಸಂಪಾದಿಸು",
    "Title" : "ಶೀರ್ಷಿಕೆ",
    "URL" : "ಜಾಲದ ಕೊಂಡಿ",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Warning" : "﻿ಎಚ್ಚರಿಕೆ",
    "Next" : "ಮುಂದೆ",
    "Name" : "﻿ಹೆಸರು",
    "Email" : "﻿ಇ-ಅಂಚೆ"
},
"nplurals=2; plural=(n > 1);");
