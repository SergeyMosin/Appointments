OC.L10N.register(
    "appointments",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Info" : "Info",
    "Delete" : "﻿ಅಳಿಸಿ",
    "Settings" : "ಆಯ್ಕೆ",
    "Close" : "ಮುಚ್ಚು",
    "Remove" : "ತೆಗೆದುಹಾಕಿ",
    "Loading" : "Loading",
    "Warning" : "﻿ಎಚ್ಚರಿಕೆ",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Edit" : "ಸಂಪಾದಿಸು",
    "Title" : "ಶೀರ್ಷಿಕೆ",
    "URL" : "ಜಾಲದ ಕೊಂಡಿ",
    "Save" : "﻿ಉಳಿಸಿ",
    "Next" : "ಮುಂದೆ"
},
"nplurals=2; plural=(n > 1);");
