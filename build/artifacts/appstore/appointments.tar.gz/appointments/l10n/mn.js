OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Батлах",
    "Cancel" : "болиулах",
    "Info" : "Info",
    "Close" : "Хаах",
    "Remove" : "Устгах",
    "Start" : "эхлэх",
    "Apply" : "хэрэглэх",
    "Warning" : "Warning",
    "Error" : "Алдаа",
    "Deleted" : "Устгагдсан",
    "Confirmed" : "Баталгаажсан",
    "Location:" : "Байршил:",
    "Back" : "буцах",
    "Next" : "дараагийх",
    "An error has occurred" : "Алдаа гарлаа"
},
"nplurals=2; plural=(n != 1);");
