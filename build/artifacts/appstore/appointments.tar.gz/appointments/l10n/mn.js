OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Батлах",
    "Cancel" : "болиулах",
    "Info" : "Info",
    "Close" : "Хаах",
    "Remove" : "Устгах",
    "Start" : "эхлэх",
    "Apply" : "хэрэглэх",
    "Deleted" : "Устгагдсан",
    "Confirmed" : "Баталгаажсан",
    "Error" : "Алдаа",
    "Warning" : "Warning",
    "Location:" : "Байршил:",
    "Back" : "буцах",
    "Next" : "дараагийх",
    "An error has occurred" : "Алдаа гарлаа"
},
"nplurals=2; plural=(n != 1);");
