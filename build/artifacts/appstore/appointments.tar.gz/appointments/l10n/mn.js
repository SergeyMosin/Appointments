OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Батлах",
    "Cancel" : "болиулах",
    "Info" : "Info",
    "Close" : "Хаах",
    "Apply" : "хэрэглэх",
    "Deleted" : "Устгагдсан",
    "Confirmed" : "Баталгаажсан",
    "Start" : "эхлэх",
    "Location:" : "Байршил:",
    "Back" : "буцах",
    "Next" : "дараагийх"
},
"nplurals=2; plural=(n != 1);");
