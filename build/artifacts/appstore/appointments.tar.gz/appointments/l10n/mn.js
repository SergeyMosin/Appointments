OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Батлах",
    "Cancel" : "болиулах",
    "Info" : "Info",
    "Close" : "Хаах",
    "Remove" : "Устгах",
    "Warning" : "Warning",
    "Start" : "эхлэх",
    "Apply" : "хэрэглэх",
    "Deleted" : "Устгагдсан",
    "Confirmed" : "Баталгаажсан",
    "Error" : "Алдаа",
    "Location:" : "Байршил:",
    "Back" : "буцах",
    "Next" : "дараагийх",
    "An error has occurred" : "Алдаа гарлаа"
},
"nplurals=2; plural=(n != 1);");
