OC.L10N.register(
    "appointments",
    {
    "Confirm" : "Батлах",
    "Cancel" : "болиулах",
    "Info" : "Info",
    "Close" : "Хаах",
    "Apply" : "хэрэглэх",
    "Start" : "эхлэх"
},
"nplurals=2; plural=(n != 1);");
