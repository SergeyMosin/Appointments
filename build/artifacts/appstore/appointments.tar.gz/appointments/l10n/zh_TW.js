OC.L10N.register(
    "appointments",
    {
    "%s Appointment is Confirmed" : "以確認您%s的預約",
    "Confirm" : "確認",
    "Cancel" : "取消",
    "Info" : "資訊",
    "Email" : "電子郵件",
    "Close" : "關閉",
    "Copy public link" : "複製公開連結",
    "Address" : "地址",
    "Apply" : "套用",
    "Start" : "起點",
    "close" : " 關閉"
},
"nplurals=1; plural=0;");
