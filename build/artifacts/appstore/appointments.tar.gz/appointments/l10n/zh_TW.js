OC.L10N.register(
    "appointments",
    {
    "Confirm" : "確認",
    "Cancel" : "取消",
    "Info" : "資訊",
    "Close" : "關閉",
    "Copy public link" : "複製公開連結",
    "Apply" : "套用",
    "Deleted" : "已刪除",
    "Confirmed" : "已確認",
    "Start" : "起點",
    "close" : " 關閉",
    "Name:" : "姓名：",
    "Location:" : "地點：",
    "Back" : "返回",
    "Next" : "下一個",
    "An error has occurred" : "發生了錯誤"
},
"nplurals=1; plural=0;");
