OC.L10N.register(
    "appointments",
    {
    "Cancel" : "បោះបង់",
    "Info" : "Info",
    "Delete" : "លុប",
    "Settings" : "ការកំណត់",
    "Close" : "បិទ",
    "Remove" : "ដកចេញ",
    "Loading" : "Loading",
    "Apply" : "អនុវត្ត",
    "Warning" : "បម្រាម",
    "Error" : "កំហុស",
    "Edit" : "កែប្រែ",
    "Title" : "ចំណងជើង",
    "URL" : "URL",
    "Save" : "រក្សាទុក",
    "Deleted" : "បាន​លុប",
    "Location:" : "ទីតាំងៈ",
    "Back" : "ត្រឡប់ក្រោយ",
    "Next" : "បន្ទាប់"
},
"nplurals=1; plural=0;");
