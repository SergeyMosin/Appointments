OC.L10N.register(
    "appointments",
    {
    "Cancel" : "បោះបង់",
    "Password" : "ពាក្យសម្ងាត់",
    "Info" : "Info",
    "Settings" : "ការកំណត់",
    "Title" : "ចំណងជើង",
    "URL" : "URL",
    "Save" : "រក្សាទុក",
    "Remove" : "ដកចេញ",
    "Add" : "បញ្ចូល",
    "OK" : "ព្រម",
    "Delete" : "លុប",
    "Location" : "ទីតាំង",
    "Deleted" : "បាន​លុប",
    "Warning" : "បម្រាម",
    "Advanced" : "កម្រិត​ខ្ពស់",
    "Edit" : "កែប្រែ",
    "Back" : "ត្រឡប់ក្រោយ",
    "Next" : "បន្ទាប់",
    "Email" : "អ៊ីមែល"
},
"nplurals=1; plural=0;");
