OC.L10N.register(
    "appointments",
    {
    "Cancel" : "បោះបង់",
    "Info" : "Info",
    "Close" : "បិទ",
    "Apply" : "អនុវត្ត",
    "Deleted" : "បាន​លុប",
    "Location:" : "ទីតាំងៈ",
    "Back" : "ត្រឡប់ក្រោយ",
    "Next" : "បន្ទាប់"
},
"nplurals=1; plural=0;");
