OC.L10N.register(
    "appointments",
    {
    "Cancel" : "បោះបង់",
    "Info" : "Info",
    "Email" : "អ៊ីមែល",
    "Close" : "បិទ",
    "Address" : "អាសយដ្ឋាន",
    "Apply" : "អនុវត្ត"
},
"nplurals=1; plural=0;");
