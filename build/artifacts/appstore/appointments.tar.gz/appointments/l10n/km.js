OC.L10N.register(
    "appointments",
    {
    "Cancel" : "បោះបង់",
    "Info" : "Info",
    "Close" : "បិទ",
    "Remove" : "ដកចេញ",
    "Warning" : "បម្រាម",
    "Apply" : "អនុវត្ត",
    "Deleted" : "បាន​លុប",
    "Error" : "កំហុស",
    "Location:" : "ទីតាំងៈ",
    "Back" : "ត្រឡប់ក្រោយ",
    "Next" : "បន្ទាប់"
},
"nplurals=1; plural=0;");
