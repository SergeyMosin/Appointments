<?php
//namespace OCA\Appointments\AppInfo;
//
//$app = new Application();
