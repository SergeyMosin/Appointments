<?php

//\OC::$server->query(OCA\Appointments\AppInfo\Application::class);
