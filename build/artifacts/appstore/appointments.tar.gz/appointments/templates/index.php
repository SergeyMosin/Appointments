<?php
    script('appointments', 'script');
    style('appointments', 'style');
?>
