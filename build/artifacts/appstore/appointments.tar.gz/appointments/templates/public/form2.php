<?php
script('appointments', 'form2');
?>


<div>
<button id="f2_btn">GO</button>
</div>