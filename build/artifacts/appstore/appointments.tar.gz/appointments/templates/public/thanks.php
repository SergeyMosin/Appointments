<?php /** @noinspection PhpUndefinedVariableInspection */
style('appointments', 'form');
?>

<div class="srgdev-ncfp-wrap">
    <div class="srgdev-appt-info-cont">
        <h1><?php p($_['appt_c_head'])?></h1>
        <p><?php p($_['appt_c_msg'])?></p>
        <p><?php p($l->t("Thank you"));?></p>
    </div>
</div>
