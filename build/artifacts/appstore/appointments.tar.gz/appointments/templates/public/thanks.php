<?php /** @noinspection PhpUndefinedVariableInspection */
style('appointments', 'form');
?>

<div class="srgdev-ncfp-wrap">
    <div class="srgdev-appt-info-cont">
        <h1><?php echo $_['appt_c_head']?></h1>
        <p><?php echo $_['appt_c_msg']?></p>
        <p>Thank You</p>
    </div>
</div>
